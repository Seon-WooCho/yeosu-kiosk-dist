/*
 * 음성·글자 질문 → 답변 (AI 모델 없이, 시트의 '질문사전'으로)
 *  1) 질문에서 관광지 이름 찾기: 여수10경·관광지의 4개국어 이름 + 별칭
 *  2) 질문 종류 찾기: 질문사전의 언어별 키워드 (가장 길게 맞는 것)
 *  3) 답변 틀의 {칸이름}을 그 관광지 내용으로 채움. 칸이 비어 있으면 '준비 중' 안내
 * 결과: { text, place, screen }  — screen 은 질문사전의 '연결 화면'
 */
(function () {
  "use strict";

  var NO_PLACE_TYPES = { "추천": 1, "축제": 1 };
  // {교통안내_ko}·{교통안내} 모두 '지금 언어'의 가는 법으로 채움 (그 언어가 비면 한국어)
  var FIELD = { "소개": "intro", "주소": "address", "전화": "tel", "운영시간": "hours", "요금": "fee", "교통안내_ko": "transit", "교통안내": "transit" };

  function norm(s) {
    return String(s || "").toLowerCase().replace(/[\s.,!?·~'"()\-?？！。、，]/g, "");
  }
  function t(obj, lang) { return obj ? (obj[lang] || obj.ko || "") : ""; }

  function placesOf(d) {
    var list = [];
    (d.tenSights || []).forEach(function (p) { list.push({ kind: "ten", p: p }); });
    (d.places || []).forEach(function (p) { list.push({ kind: "place", p: p }); });
    return list;
  }

  function findPlace(d, q) {
    var nq = norm(q), best = null, bestLen = 0;
    placesOf(d).forEach(function (it) {
      var names = [it.p.name.ko, it.p.name.en, it.p.name.ja, it.p.name.zh].concat(it.p.aliases || []);
      names.forEach(function (n) {
        // 'XX·YY' 같은 이름은 앞부분만 말해도 찾도록 나눠서도 비교
        String(n || "").split(/[·\/]/).concat([n]).forEach(function (part) {
          var k = norm(part);
          if (k.length >= 2 && nq.indexOf(k) >= 0 && k.length > bestLen) { best = it; bestLen = k.length; }
        });
      });
    });
    return best;
  }

  function findIntent(d, q, lang) {
    var nq = norm(q), best = null, bestLen = 0;
    (d.intents || []).forEach(function (it) {
      var kws = (it.keywords[lang] || []).concat(lang === "ko" ? [] : it.keywords.ko || []);
      kws.forEach(function (k) {
        var nk = norm(k);
        if (nk && nq.indexOf(nk) >= 0 && nk.length > bestLen) { best = it; bestLen = nk.length; }
      });
    });
    return best;
  }

  function recommend(d, q, lang) {
    var nq = norm(q), all = (d.tenSights || []).slice();
    var tagged = all.filter(function (p) { return (p.tags || []).some(function (tg) { return nq.indexOf(norm(tg)) >= 0; }); });
    var pool = tagged.length ? tagged : all;
    pool = pool.slice().sort(function () { return Math.random() - 0.5; }).slice(0, 3);
    return { names: pool.map(function (p) { return t(p.name, lang); }).join(", "), first: pool[0] };
  }

  /**
   * ask(질문, 언어, UI문구함수) → { text, place, kind, screen, examples }
   */
  function ask(q, lang, ui) {
    var d = window.KioskData && KioskData.data;
    if (!d) return { text: ui("noData") };
    var found = findPlace(d, q);
    var intent = findIntent(d, q, lang);
    if (!intent && found) intent = (d.intents || []).filter(function (i) { return i.type === "소개"; })[0] || null;
    if (!intent) return { text: ui("msg.notUnderstood"), examples: true };

    var needsPlace = !NO_PLACE_TYPES[intent.type];
    if (needsPlace && !found) return { text: ui("whichPlace"), choosePlace: true };

    var tpl = t(intent.answer, lang), missing = false, rec = null;
    var name = found ? t(found.p.name, lang) : "";
    var text = tpl.replace(/\{([^}]+)\}/g, function (_, key) {
      if (key === "이름") return name;
      if (key === "추천 3곳") { rec = recommend(d, q, lang); return rec.names; }
      if (key === "메인영상 제목") {
        var titles = KioskData.activeMainMedia().filter(function (m) { return !m.isDefault; }).map(function (m) { return t(m.title, lang); });
        if (!titles.length) missing = true;
        return titles.slice(0, 3).join(", ");
      }
      var f = FIELD[key];
      var raw = found && f ? found.p[f] : "";
      var v = raw && typeof raw === "object" ? t(raw, lang) : (raw || "");
      if (!v) missing = true;
      return v || "";
    });
    if (missing) text = ui(intent.type === "축제" ? "noFestival" : "noInfo").replace("{이름}", name);

    var target = found || (rec && rec.first ? { kind: "ten", p: rec.first } : null);
    return { text: text, place: target, screen: intent.screen, type: intent.type };
  }

  window.KioskQA = { ask: ask, findPlace: findPlace, norm: norm };
})();
